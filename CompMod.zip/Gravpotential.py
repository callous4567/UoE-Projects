import sys
import math
import numpy as np
from numpy import linalg as LA
import matplotlib.pyplot as pyplot
from Particle3D import Particle3D

def gravforce(p1, p2, G):
    force = G*p1.mass*p2.mass*P3D.sep(p1,p2)/(P3D.sepdist(p1,p2))**3
    return force

def gravpotential(p1,p2,G):
    potential = -G*p1.mass*p2.mass/P3D.sepdist(p1,p2)
    return potential

def main():

    # Open output file
    
    outfile1 = open("VerletParticleEnergy.dat", "w")
    parameters = open("parameters.dat", "r")
    particle_file = open("particles.dat", "r")
    
    #create a list of particles from the file
    particle_list = Particle3D.new_particle(particle_file)
    for line in parameters.readlines():
            partline = line.split(", ")
            
    # Set up simulation parameters
    dt = partline[0]
    numstep = partline[1]
    time = 0.0
    GravConst = partline[2]
    error1 = float(dt)*0.1


    Bodylist = []
    # creates some Particle3D objects from the list of particles
    for ii in range (len(particle_list)):
        Bodylist.append(Particle3D(particle_list[ii]))
        print(Bodylist[ii].label)
        
    forcelist = []
    newforcelist = []
    filehandlelist = []
    
    for i in range(len(Bodylist)):
        force_initial = np.array([0,0,0])
        filehandlelist.append(Bodylist[i].name)
        for j in range(len(Bodylist)):
            if i==j:
                pass
            force_initial += gravforce(Bodylist[i],Bodylist[j])
        forcelist.append(force_initial)
        
    
    for t in range(numstep):
        
        for i in range(len(Bodylist)):
            filehandlelist[i].append(Bodylist[i].__str__)
            Bodylist[i].leap_pos2nd(dt, forcelist[i])
        
        for i in range(len(Bodylist)):
            force_new_i = np.array([0,0,0])
            for j in range(len(Bodylist)):
                if i==j:
                    pass
                force_new_i += gravforce(Bodylist[i],Bodylist[j],G)
            newforcelist.append(force_new_i)
            
        
        for i in range(len(Bodylist)):
            Bodylist[i].leap_velocity(dt,(forcelist[i]+newforcelist[i])/2)
            
        
        forcelist[i] = newforcelist[i]
        newforcelist = []
        
        time += dt
        
        